<?php

return [
    'mp3' => 'mp3',
    'opus' => 'opus',
    'aac' => 'aac',
    'flac' => 'flac'
];
