<?php

return [
    'mp3' => 'mp3',
    'ogg_vorbis' => 'ogg',
    'pcm' => 'pcm',
];
