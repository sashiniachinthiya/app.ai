<?php

return [
    'alloy' => [
        'name' => 'Alloy',
        'gender' => 'female',
    ],

    'echo' => [
        'name' => 'Echo',
        'gender' => 'male',
    ],

    'fable' => [
        'name' => 'Fable',
        'gender' => 'male',
    ],

    'onyx' => [
        'name' => 'Onyx',
        'gender' => 'male',
    ],

    'nova' => [
        'name' => 'Nova',
        'gender' => 'female',
    ],

    'shimmer' => [
        'name' => 'Shimmer',
        'gender' => 'female',
    ],
];
