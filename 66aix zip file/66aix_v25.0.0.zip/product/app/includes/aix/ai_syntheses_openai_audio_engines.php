<?php

return [
    'tts-1', 'tts-1-hd'
];
