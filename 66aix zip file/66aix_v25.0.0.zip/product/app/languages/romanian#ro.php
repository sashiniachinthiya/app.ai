<?php

return [
	'direction' => 'ltr',
];